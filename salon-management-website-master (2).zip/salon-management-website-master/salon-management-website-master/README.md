# salon-management-website
salon management
Install the xampp and start the server and mysql.
keep the unzip files in htdocs.
Import the database file in the phpmyadmin.
This website contains the features of appointment booking and billing system.
We can see the data from the database from the admin page.

